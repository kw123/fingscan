#!/bin/sh
#
# Copyright 2012 by Overlook

rm -f /usr/local/bin/fing
rm -f /usr/local/bin/fing-uninstall.sh
rm -rf /usr/local/lib/fing
rm -rf /etc/fing
rm -rf /usr/share/fing
rm -f /Library/LaunchDaemons/com.overlooksoft.FingSentinel.plist
rm -rf /var/log/fing
rm -rf /var/data/fing
